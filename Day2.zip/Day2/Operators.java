/* Operator Practice Question:
Write a Java program that:

Takes two integers as input from the user.

Calculates and prints:

Their sum (+)

Their difference (-)

Their product (*)

Their quotient (/) — handle division by zero gracefully

Their remainder (%)

Checks and prints whether the first number is greater than the second (>)

Checks if both numbers are equal (==)

Demonstrates the use of logical operators (&&, ||) by printing whether both numbers are positive, or at least one number is zero.*/

import java.util.Scanner;

class Operators  {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enetr x value");
        float x = sc.nextFloat();
        System.out.println("Enter y value");
        float y = sc.nextFloat();
        System.out.println("the sum is:"+(x+y));
        System.out.println("the difference is:"+(x-y));
        System.out.println("the product is:"+(x*y));
        
        if (y != 0) {
        System.out.println("the quotient is:"+(x/y));
        System.out.println("the remainder is:"+(x%y));
        }else{
             System.out.println("Cannot divide by zero!");
        }
        if(x>y)
        {
            System.out.println("the highest number is:"+x);
        }
        else
        {
            System.out.println("the highest value is:"+y);
        }
        if(x==y)
        {
            System.out.println("both are equal");
        }
        if((x>0)&&(y>0))
        {
            System.out.println("both are positive");
        }
        if((x==0)||(y==0))
        {
            System.out.println("At least one number is zero");
        }
        sc.close();

    }
    
}
